function x = LocalMin(fun, fmin, fmax, eps, paras)
    a = fmin; b = fmax;
    % c is the squared inverse of the golden ratio
    c = (3 - 5^0.5) / 2; d = 0; e = 0;
    % eps is approximately the square root of relative machine precision.
    tol = eps^0.25;
    eps = tol^2;
    % the smallest 1.000... > 1 : tol1 = 1 + eps**2
    v = a + c * (b - a); w = v; x = v;
    fv = feval(fun, x, paras); fw = fv; fx = fv;
    % main loop starts here
    while 1
        m = (a + b) / 2;
        tol1 = eps * abs(x) + tol / 3;
        tol2 = tol1 * 2;
        % check stopping criterion
        if abs(x - m) <= tol2 - (b - a) / 2
            break
        end
        p = 0; q = 0; r = 0;
        % fit parabola
        if abs(e) > tol1
            r = (x - w) * (fx - fv);
            q = (x - v) * (fx - fw);
            p = (x - v) * q - (x - w) * r;
            q = (q - r) * 2;
            if q > 0
                p = -p;
            else
                q = -q;
            end
            r = e; e = d;
        end
        if abs(p) >= abs(0.5 * q * r) || p <= q * (a-x) || p >= q * (b-x)
            % a golden-section step
            if x < m
                e = b - x;
            else
                e = a - x;
            end
            d = c * e;
        else
            % a parabolic-interpolation step
            d = p / q;
            u = x + d;
            % f must not be evaluated too close to ax or bx
            if u - a < tol2 || b - u < tol2
                if x < m
                    d = tol1;
                else
                    d = -tol1;
                end
            end
        end
        % f must not be evaluated too close to x
        if abs(d) >= tol1
            u = x + d;
        else
            if d > 0
                u = x + tol1;
            else
                u = x - tol1;
            end
        end
        fu = feval(fun, u, paras);
        % update  a, b, v, w, and x
        if fu <= fx
            if u < x
                b = x;
            else
                a = x;
            end
            v = w; fv = fw; w = x; fw = fx; x = u; fx = fu;
        else
            if u < x
                a = u;
            else
                b = u;
            end
            if fu <= fw || w == x
                v = w; fv = fw; w = u; fw = fu;
            else
                if fu <= fv || v == x || v == w
                    v = u; fv = fu;
                end
            end
        end
    end
    % end of main loop
end