function H = EstHurstLSSD(ts, p, q, eps)

    if nargin < 4
        eps = 1e-6;
    end
    if nargin < 3
        q = 50;
    end
    if nargin < 2
        p = 6;
    end

    N = length(ts);
    max_scale = floor(N / 10);
    T = [1:max_scale]';
    S = zeros(max_scale, 1);
    for i = 1:max_scale
        k = floor(N / i);
        Z = sum(reshape(ts(mod(N, i)+1:end), i, k), 1);
        S(i) = std(Z);
    end
    
    paras = zeros(max_scale, 3);
    paras(1, 1) = N;
    paras(2, 1) = p;
    paras(3, 1) = q;
    paras(:, 2) = T;
    paras(:, 3) = S;
    H = FixedPointSolver('CtmLSSD', 0.5, eps, paras);
    
end