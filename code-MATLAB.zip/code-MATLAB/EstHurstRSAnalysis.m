function H = EstHurstRSAnalysis(ts, n_min, IsRandom)
    if nargin < 3
        IsRandom = 0;
    end
    if nargin < 2
        n_min = 10;
    end
    
    N = length(ts);
    Nopt = findOptN(N, n_min);
    T = Divisors(Nopt, n_min);
    
    RSe = zeros(length(T), 1);
    ERS_AL = zeros(length(T), 1);
    for i = 1:length(T)
        
        k = Nopt / T(i);
        RSm = zeros(k, 1);
        x = reshape(ts(N - Nopt + 1:end), T(i), k);
        for j = 1:k
            avg = mean(x(:, j));
            y = cumsum(x(:, j) - avg);
            r = max(y) - min(y);
            s = std(x(:, j));
            RSm(j) = r / s;
        end
        RSe(i) = mean(RSm);
        
        K = 1:T(i)-1;
        ratio = (T(i) - 0.5) / T(i) * sum(sqrt((-K + T(i)) ./ K));
        if T(i) > 340
            ERS_AL(i) = ratio / sqrt(0.5 * pi * T(i));
        else
            ERS_AL(i) = (gamma((T(i)-1)/2)*ratio)/(gamma(T(i)/2)*sqrt(pi));
        end
    end
    ERS = sqrt(0.5 * pi * T);
    if IsRandom
        RS = RSe - ERS_AL + ERS;
    else
        RS = RSe;
    end
    
    P = polyfit(log10(T), log10(RS), 1);
    H = P(1);
end