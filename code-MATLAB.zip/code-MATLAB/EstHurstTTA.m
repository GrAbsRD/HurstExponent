function H = EstHurstTTA(ts, max_scale)
    if nargin < 2
        max_scale = 10;
    end
    
    N = length(ts);
    T = 1:max_scale;
    S = zeros(max_scale, 1);
    y = cumsum(ts - mean(ts));
    for tau = 1:max_scale
        s = 0;
        for i = 1:floor((N - 1) / (2 * tau))
            j = 2 * (i - 1) * tau + 1;
            s = s + abs(y(j + 2 * tau) - 2 * y(j + tau) + y(j));
        end
        S(tau) = 0.5 * tau * s;
    end
    
    % P = polyfit(log10(T'), log10(S), 1);
    [A, b] = FormatPowLawData(T', S);
    P = LinearRegrSolver(A, b);
    
    H = P(1);
end