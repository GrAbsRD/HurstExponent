function H = EstHurstDFAnalysis(ts, n_min)

    if nargin < 2
        n_min = 10;
    end
    
    N = length(ts);
    Nopt = findOptN(N, n_min);
    T = Divisors(Nopt, n_min);
    
    ts = ts(N - Nopt + 1:end);
    Z = cumsum(ts - mean(ts));
    
    S = zeros(length(T), 1);
    for i = 1:length(T)
        k = Nopt / T(i);
        y = reshape(Z, T(i), k);
        e = zeros(size(y));
        t = 1:T(i);
        for j = 1:k
            p = polyfit(t', y(:, j), 1);
            e(:, j) = y(:, j) - t' * p(1) - p(2);
        end
        S(i) = mean(std(e));
    end
    
    % P = polyfit(log10(T), log10(S), 1);
    [A, b] = FormatPowLawData(T, S);
    P = LinearRegrSolver(A, b);
    
    H = P(1);
    
end
