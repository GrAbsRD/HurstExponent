function H = EstHurstLW(ts)

    N = length(ts);
    y = fft(ts);
    n = floor(N / 2);
    T = [1:n]' / N;
    S = abs(y(2:n+1)).^2;
    
    H = LocalMin('ObjFunLW', 0.001, 0.999, 1e-8, [T, S]);
    
end
