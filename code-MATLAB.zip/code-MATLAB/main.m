
clear; clc;

H = 0.5;
n = 1000;
k = 10;

h = zeros(k, 1);
for i = 1:k
    ts = fgn(H, n);
    % ts = randn(n, 1);
    % h(i) = EstHurstCentral(ts, 2, 30);
    % h(i) = EstHurstDFAnalysis(ts, 50);
    % h(i) = EstHurstGHE(ts);
    % h(i) = EstHurstHiguchi(ts);
    % h(i) = EstHurstTTA(ts);
    % h(i) = EstHurstRSAnalysis(ts, 50, 0);
    % h(i) = EstHurstPeriodogram(ts);
    % h(i) = EstHurstDWT(ts, 1);
    % h(i) = EstHurstLW(ts);
    % h(i) = EstHurstLSSD(ts, 6, 0);
    h(i) = EstHurstLSV(ts, 6, 0);
end
disp(mean(h))
