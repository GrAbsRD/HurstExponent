function y = CtmLSV(H, paras)

    N = paras(1, 1);
    p = paras(2, 1);
    q = paras(3, 1);
    T = paras(:, 2);
    S = paras(:, 3);
    a11 = 0; a12 = 0; b1 = 0;
    b2 = H^(q + 1) / (q + 1);
    
    max_scale = length(T);
    for i = 1:max_scale
        m = T(i);
        c = FunCmLSV(m, N, H);
        u = m^p;
        a11 = a11 + c^2 * m^(4*H) / u;
        a12 = a12 + c * m^(2*H) * S(i)^2 / u;
        b1 = b1 + S(i)^4 / u;
    end
    
    y = b1 - a12^2 / a11;
    if q ~= 0
        y = y + b2;
    end

end

function c = FunCmLSV(m, N, H)

    u = N / m;
    c = (u - u^(2*H-1)) / (u - 1);
    
end
