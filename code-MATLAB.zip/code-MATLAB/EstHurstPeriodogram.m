function H = EstHurstPeriodogram(ts, cutoff)
    
    if nargin < 2
        cutoff = 0.5;
    end
    
    N = length(ts);
    y = fft(ts);
    y = y(2:floor(N / 2) + 1);
    freqs = (1:floor(N / 2)) / N;
    index = freqs < 1 / N^cutoff;
    T = 4 * sin(freqs(index) / 2).^2;
    S = abs(y(index)).^2 / N;
    
    % P = polyfit(log10(T'), log10(S), 1);
    [A, b] = FormatPowLawData(T', S);
    P = LinearRegrSolver(A, b);
    
    H = 0.5 - P(1);
    
end