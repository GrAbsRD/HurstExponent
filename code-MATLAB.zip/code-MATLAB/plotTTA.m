
clc; clear;

n = 20;
% ts = fgn(0.8, n);
ts = [0.0625, 0.0700, 0.0318, 0.0233, 0.1881, ...
      0.0880, 0.1754, 0.0941, 0.0739, 0.0042, ...
      0.1281, -0.0050, 0.0056, 0.0192, 0.1165, ...
      0.0714, 0.0613, -0.0994, -0.0452, 0.0338]';

x = 1:n;

figure(1);
set(gcf,'color','w');
for tau = 1:4

    subplot(2, 2, tau);
    y = 1:2*tau:n-2*tau;

    Y = zeros(3, 1);
    for i = 1:2*tau:n-2*tau
        Y(1) = ts(i);
        Y(2) = ts(i + tau);
        Y(3) = ts(i + 2 * tau);
        X = [i, i+tau, i+2*tau];
        fill(X, Y, 'r');
        hold on;
    end
    
    title(['\tau = ', num2str(tau, "%d")], 'fontsize', 24,...
          'FontName','Times');
    plot(x, ts, '-ko',...
         'LineWidth', 2.5,...
         'MarkerSize', 6,...
         'MarkerFaceColor', 'k');
    hold on;
    axis tight;
    axis off;

end
