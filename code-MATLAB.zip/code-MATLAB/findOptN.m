function nOpt = findOptN(n, n_min)
    n0 = floor(0.99 * n);
    s = zeros(n - n0 + 1, 1);
    for i = n0:n
        d = Divisors(i, n_min);
        s(i - n0 + 1) = length(d);
    end
    nOpt = n0 + find(max(s) == s) - 1;
end