function y = CtmLSSD(H, paras)

    N = paras(1, 1);
    p = paras(2, 1);
    q = paras(3, 1);
    T = paras(:, 2);
    S = paras(:, 3);
    a11 = 0; a12 = 0; a21 = 0; a22 = 0;
    b1 = 0; b2 = 0;
    
    max_scale = length(T);
    for i = 1:max_scale
        m = T(i);
        c = FunCmLSSD(m, N, H);
        d = FunDmLSSD(m, N, H);
        u = m^p;
        a11 = a11 + 1 / u;
        a12 = a12 + log(m) / u;
        a21 = a21 + d / u;
        a22 = a22 + d * log(m) / u;
        b1 = b1 + (log(S(i)) - log(c)) / u;
        b2 = b2 + d * (log(S(i)) - log(c)) / u;
    end
    if q == 0
        g1 = a11*b2 - a21*b1;
    else
        g1 = a11*(b2-H^q) - a21*b1;
    end
    g2 = a11*a22 - a21*a12;
    y = g1 / g2;
    
end

function c = FunCmLSSD(m, N, H)

    u = N / m;
    c = sqrt((u - u^(2*H-1)) / (u - 0.5));
    
end

function d = FunDmLSSD(m, N, H)

    u = N / m;
    d = log(m) + log(u) / (1 - u^(2-2*H));
    
end