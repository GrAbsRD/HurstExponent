function f = fgn(H, n)
    k = 0:n-1;
    rho = zeros(n, 1);
    for i = 1:n
        rho(i) = 0.5 * (...
            abs(k(i) - 1)^(2*H) - ...
            2 * abs(k(i))^(2*H) + ...
            abs(k(i) + 1)^(2*H)   ...
        );
    end
    rho2 = [rho; 0; flipud(rho(2:end))];
    g = fft(rho2);
    v = sqrt(g);
    a = randn(n, 1);
    b = randn(n, 1);
    w = zeros(2 * n, 1);
    w(1) = v(1) / sqrt(2 * n) * a(1);
    for i = 2:n
        w(i) = v(i) / sqrt(4 * n) * (a(i) + 1i * b(i));
        w(n + i) = v(n+i) / sqrt(4 * n) * (a(n-i+2) - 1i * b(n-i+2));
    end
    w(n + 1) = v(n + 1) / sqrt(2 * n) * b(1);
    r = real(fft(w));
    f = r(1:n) / n^H;
end