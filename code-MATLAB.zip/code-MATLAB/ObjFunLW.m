function y = ObjFunLW(x, paras)
    
    T = paras(:, 1);
    S = paras(:, 2);
    n = length(T);
    y1 = mean(T.^(2*x-1) .* S);
    y2 = (2*x-1) * mean(log(T));
    y = log(y1) - y2;
    
end