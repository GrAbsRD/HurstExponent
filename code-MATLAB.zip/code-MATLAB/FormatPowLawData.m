function [A, b] = FormatPowLawData(x, y)
    
    n = length(x);
    A = [log(x), ones(n, 1)];
    b = log(y);
    
end
