function H = EstHurstCentral(ts, order, n_min)

    if nargin < 3
        n_min = 10;
    end
    if nargin < 2
        order = 2;
    end
    
    N = length(ts);
    NOpt = findOptN(N, n_min);
    T = Divisors(NOpt, n_min);
    
    ts = ts(N - NOpt + 1:end);
    avg = mean(ts);
    
    S = zeros(length(T), 1);
    for i = 1:length(T)
        k = NOpt / T(i);
        x = reshape(ts, T(i), k);
        y = mean(x) - avg;
        % s(i) = var(y);
        S(i) = mean(abs(y).^order);
    end
    
    % P = polyfit(log10(d), log10(cm), 1);
    [A, b] = FormatPowLawData(T, S);
    P = LinearRegrSolver(A, b);

    H = P(1) / order + 1;
    
end
