function y = FixedPointSolver(f, x_guess, eps, paras)
    
    k = 0;
    x_improve = feval(f, x_guess, paras);
    while (abs(x_improve - x_guess) > eps) && k < 10000
        x_guess = x_improve;
        x_improve = feval(f, x_guess, paras);
        k = k + 1;
    end
    y = x_improve;
    
end
