function H = EstHurstGHE(ts, q, max_scale)

    if nargin < 3
        max_scale = 10;
    end
    if nargin < 2
        q = 2;
    end
    
    N = length(ts);
    T = 1:max_scale;
    Y = cumsum(ts - mean(ts));
    S = zeros(max_scale, 1);
    for i = 1:max_scale
        kq = mean(abs(Y(1+i:end) - Y(1:N-i)).^q);
        S(i) = kq;
    end
    
    % P = polyfit(log10(t'), log10(k), 1);
    [A, b] = FormatPowLawData(T', S);
    P = LinearRegrSolver(A, b);
    
    H = P(1) / q;
    
end