function P = LinearRegrSolver(A, b)

    P = pinv(A) * b;
    
end
