function H = EstHurstDWT(ts, r, wavemode)

    if nargin < 3
        wavemode = 'per';
    end
    if nargin < 2
        r = 1;
    end
    
    N = length(ts);
    n = floor(log2(N));
    dwtmode(wavemode, 'nodisp');
    if r == 1
        [C, L] = wavedec(ts, n, 'db24');
    else
        [C, L] = wavedec(ts, n, 'haar');
    end
    T = 2.^[1:n]';
    S = zeros(n, 1);
    for i = 1:n
        W = abs(detcoef(C, L, i));
        if r == 1
            S(i) = mean(W);
        else
            S(i) = var(W);
        end
    end
    
    [A, b] = FormatPowLawData(T, S);
    P = LinearRegrSolver(A, b);
    
    H = P(1) / r + 0.5;
    
end