function H = EstHurstHiguchi(ts, max_scale)
    if nargin < 2
        max_scale = 10;
    end
    
    N = length(ts);
    y = cumsum(ts - mean(ts));
    T = zeros(max_scale, 1);
    S = zeros(max_scale, 1);
    for i = 1:max_scale
        if i > 4
            m = floor(2^((i + 5) / 4));
        else
            m = i;
        end
        T(i) = m;
        k = floor(N / m);
        x = reshape(y(mod(N, k) + 1:end), m, k);
        l = 0;
        for j = 2:k
            l = l + sum(abs(x(:, j) - x(:, j - 1)));
        end
        l = l / m / (k - 1);
        S(i) = (N - 1) * l / m^2;
    end
    
    % P = polyfit(log10(T), log10(S), 1);
    [A, b] = FormatPowLawData(T, S);
    P = LinearRegrSolver(A, b);
    
    H = P(1) + 2;
end