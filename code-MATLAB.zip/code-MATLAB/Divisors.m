function d = Divisors(n, n_min)
    % Find all divisors of the natural number N
    % greater or equal to N0
    i = n_min:ceil(n/n_min);
    d = find((n./i)==floor(n./i))' + n_min - 1;
end